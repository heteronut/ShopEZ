const express = require("express");
const { getProfile, updateProfile } = require("../controllers/authController");
const { protect } = require("../middleware/auth");

const router = express.Router();
router.get("/profile", protect, getProfile);
router.put("/profile", protect, updateProfile);
module.exports = router;
